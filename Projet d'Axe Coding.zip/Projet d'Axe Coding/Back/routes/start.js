
import express from "express";

import AuthControllers from "../controllers/authenticationController.js";
import UsersController from "../controllers/UsersController.js";
import ProfileController from "../controllers/ProfileControllers.js";

const router = express.Router();

// API for users
router.get("/users", UsersController.index);
// POST /users with users controller store method
router.post("/users", UsersController.store);
// GET /users/:id with users controller show method
router.get("/users/:id", UsersController.show);
// PUT /users/:id with users controller update method
router.put("/users/:id", UsersController.update);
// DELETE /users/:id with users controller delete method
router.delete("/users/:id", UsersController.delete);

// API for cards
//router.get("/cards", CardController.index);
//router.get("/cards/:slug", CardController.show);
//router.get("/cards/:id", CardController.getCardById);

// auth routes
router.post("/sign-up", AuthControllers.register);
router.post("/sign-in", AuthControllers.login);
router.post("/sign-out", AuthControllers.logout);

// get the user profile
router.get("/getProfile", ProfileController.getProfile);


export default router;