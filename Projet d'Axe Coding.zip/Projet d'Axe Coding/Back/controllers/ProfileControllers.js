import jwt from "jsonwebtoken";
import { prisma } from "../config/prisma.js";
class ProfileController {
    async getProfile(req, res) {
      const token = req.headers["x-access-token"];
  
      if (token === "undefined" || token === null || token === undefined)
        return res.status(401).json({ error: "No token provided" });
  
      jwt.verify(token, process.env.TOKEN_SECRET, (error, decoded) => {
        if (error) return res.status(403).json({ error: "Forbidden" });
  
        prisma.user
          .findUnique({
            where: {
              id: decoded.id,
            },
            include: {
              cards: true, // Charger les cartes de l'utilisateur
            },
          })
          .then((user) => {
            res.json(user);
            // console.log(user);
          })
          .catch((e) => {
            console.log(e);
            res.status(500).json({ message: e.message });
          });
      });
    }
  }
  
  export default new ProfileController();