// import { generateAccessToken } from "../utils/jwt.js";
import { comparePassword, hashPassword } from "../utils/hashPassword.js";
import { prisma } from "../config/prisma.js";
import jwt from "jsonwebtoken";

class AuthControllers {
  async login(req, res) {
    try {
      const body = req.body;

      const user = await prisma.user.findUnique({
        where: {
          email: body.emailLogin,
        },
      });
      console.log(user);
      if (!user) return res.status(404).json({ message: "User not found" });

      const isSamePassword = await comparePassword(
        body.passwordLogin,
        user.password
      );
      console.log(isSamePassword);
      if (!isSamePassword)
        return res.status(401).json({ message: "Invalid password" });

      const token = jwt.sign(
        { id: user.id, email: user.email },
        process.env.TOKEN_SECRET,
        {
          expiresIn: "2h",
        }
      );

      console.log(token);

      res.json(token);
    } catch (e) {
      return res.status(500).json({ message: e.message });
    }
  }

  async register(req, res) {
    // validate the data before creating a user with the schema
    const body = req.body;
    //const output = await vine.validate({
      //schema,
      //data: body,
    //});

    //if (output.errors) {
      //return res.status(400).json({ message: output.errors });
    //}
    try {
      const encryptedPassword = await hashPassword(body.password);
      const user = await prisma.user.create({
        data: {
          email: body.email,
          username: body.username,
          password: encryptedPassword,
        },
      });
      console.log(user);
      const token = jwt.sign(
        { id: user.id, email: user.email },
        process.env.TOKEN_SECRET,
        {
          expiresIn: "2h",
        }
      );
      console.log(token);
      res.json(token);
    } catch (e) {
      return res.status(500).json({ message: e.message });
    }
  }

  async logout(req, res) {
    // remove the token from the client
    req.headers["x-access-token"] = null;
    // destroy the token
res.json({ message: "User logged out successfully" });
  }
}

export default new AuthControllers();