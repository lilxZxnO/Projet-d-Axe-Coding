const signUp = async () => {
    let email = document.querySelector('input[name="email"]').value;
    let username = document.querySelector('input[name="username"]').value;
    let password = document.querySelector('input[name="password"]').value;
  
    let response = await fetch("http://localhost:3001/sign-up", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        email: email,
        username: username,
        password: password,
      }),
    });
  
    let data = await response.json();
    localStorage.setItem("token", data);
    window.location.href = "profil.html";
  };