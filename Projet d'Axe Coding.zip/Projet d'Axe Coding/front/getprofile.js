const username = document.getElementById("user-name");

let token = localStorage.getItem("token");

if (!token) {
  window.location.href = "login.html";
}

fetch("http://localhost:3001/getProfile", {
  headers: {
    "x-access-token": `${token}`,
  },
})
  .then((response) => response.json())
  .then(async (data) => {
    // Si le token est invalide, rediriger vers la page de connexion
    if (data.error) {
      window.location.href = "login.html";
    }

    // Afficher le nom d'utilisateur
    username.innerHTML = data.username;
  });
