const signInBtnLink = document.querySelector('.signInBtn-link');
const signUpBtnLink = document.querySelector('.signUpBtn-link');
const wrapper = document.querySelector('.wrapper');
signUpBtnLink.addEventListener('click', () => {
    wrapper.classList.toggle('active');
});
signInBtnLink.addEventListener('click', () => {
    wrapper.classList.toggle('active');
});

const signIn = async () => {
    let email = document.querySelector('input[name="emailLogin"]').value;
    let password = document.querySelector('input[name="passwordLogin"]').value;
    // get the response from the server
    let response = await fetch("http://localhost:3001/sign-in", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        email: email,
        password: password,
      }),
    });
    // get the data from the response
    let data = await response.json();
    localStorage.setItem("token", data);
  
    window.location.href = "profile.html";
  };