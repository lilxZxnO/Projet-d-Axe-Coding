document.addEventListener('DOMContentLoaded', function () {
    const userName = 'John Doe'; // Nom de l'utilisateur connecté
    document.getElementById('user-name').textContent = `Welcome, ${userName}`;

    const userCards = [
        'Harry Potter',
        'Hermione Granger',
    ];

    const friends = ['Friend 1', 'Friend 2', 'Friend 3'];

    const tradeRequests = [
        { from: 'Friend 1', card: 'Draco Malfoy' },
        { from: 'Friend 2', card: 'Luna Lovegood' },
        
    ];

    
    async function fetchCharacterImages() {
        const response = await fetch('https://hp-api.lainocs.fr/characters');
        const characters = await response.json();
        const characterMap = characters.reduce((acc, character) => {
            acc[character.name] = { image: character.image, description: character.actor };
            return acc;
        }, {});
        return characterMap;
    }

    // Populate cards
    async function populateCards() {
        const characterMap = await fetchCharacterImages();
        const cardsContainer = document.querySelector('.cards-container');
        userCards.forEach(card => {
            if (characterMap[card]) {
                const cardElement = document.createElement('div');
                cardElement.classList.add('card');
                cardElement.innerHTML = `
                    <img src="${characterMap[card].image}" alt="${card}">
                    <h2>${card}</h2>
                    <p>${characterMap[card].description}</p>
                    <i class="fas fa-heart heart-icon"></i>
                `;
                cardsContainer.appendChild(cardElement);
            }
        });
    }

    // Populate friends
    function populateFriends() {
        const friendsList = document.querySelector('.friends-list');
        friends.forEach(friend => {
            const friendElement = document.createElement('li');
            friendElement.textContent = friend;
            friendsList.appendChild(friendElement);
        });
    }

    // Populate trade requests
    async function populateTradeRequests() {
        const characterMap = await fetchCharacterImages();
        const tradeRequestsList = document.querySelector('.trade-requests-list');
        tradeRequests.forEach(request => {
            if (characterMap[request.card]) {
                const requestElement = document.createElement('li');
                requestElement.innerHTML = `
                    <div class="card">
                        <img src="${characterMap[request.card].image}" alt="${request.card}">
                        <h2>${request.card}</h2>
                        <p>${characterMap[request.card].description}</p>
                    </div>
                    <p>${request.from} wants to trade</p>
                    <button>Accept</button>
                    <button>Decline</button>
                `;
                tradeRequestsList.appendChild(requestElement);
            }
        });
    }

    populateCards();
    populateFriends();
    populateTradeRequests();
});